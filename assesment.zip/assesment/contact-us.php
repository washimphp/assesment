<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contact Us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  </head>
  <body>
    <div class="container" style="padding-top:100px;">
        <div class="row d-flex justify-content-center">
            <div class="col-md-6">
                <?php
                if(isset($_REQUEST['success']))
                {
                  echo'<p class="text-center text-primary"> Submitted Successfully</p>';
                }
                ?>
                <?php
                if(isset($_REQUEST['already_submitted']))
                {
                  echo'<p class="text-center text-danger">Already Submitted</p>';
                }
                ?>
                <h4 class="mb-3 text-center">Contact Us<h4>
                <form action="action.php" method="post">
                  <div class="mb-3">
                    <label>Full Name</label>
                    <input type="text" class="form-control" name="full_name" placeholder="Enter Your Full Name" required>
                  </div>
                  <div class="mb-3">
                    <label>Phone Number</label>
                    <input type="text" class="form-control" name="phone_number" maxlength="10" placeholder="1234567890" required>
                  </div>
                  <div class="mb-3">
                    <label>Email</label>
                    <input type="email" class="form-control" name="email" placeholder="example@email.com" required>
                  </div>
                  <div class="mb-3">
                    <label>Subject</label>
                    <input type="text" class="form-control" name="subject"  placeholder="Enter Subject" required>
                  </div>
                  <div class="mb-3">
                    <label>Message</label>
                    <textarea  class="form-control" name="message" placeholder="Message" required></textarea>
                  </div>
                  <div class="mb-3">
                    <button type="submit" name="submit" class="btn btn-primary" style="float:right;">Submit</button>
                  </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
  </body>
</html>