<?php
$servername = 'localhost';
$username = 'root';
$password= '';
$dbname = 'assesment';

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  // Check if the form was submitted
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $full_name = $_POST["full_name"];
      $email = $_POST["email"];
      $phone_number = $_POST["phone_number"];
      $subject = $_POST["subject"];
      $message = $_POST["message"];
      $user_ip = $_SERVER['REMOTE_ADDR'];
      $timestamp=date('Y-m-d H:i:s');

      if (empty($full_name) || empty($email) || empty($phone_number) || empty($subject) || empty($message)) {
          echo "All fields are required.";
      } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          echo "Invalid email address.";
      } else {
          $stmt = $conn->prepare("SELECT email FROM contact_form WHERE email = :email");
          $stmt->bindParam(':email', $email);
          $stmt->execute();

          if ($stmt->rowCount() > 0) {
              echo "This email address has already exist.";
          } else {
              $stmt = $conn->prepare("INSERT INTO contact_form (full_name, email, phone_number, subject, message,user_ip,timestamp) VALUES (:full_name, :email, :phone_number, :subject, :message, :user_ip, :timestamp)");
              $stmt->bindParam(':full_name', $full_name);
              $stmt->bindParam(':email', $email);
              $stmt->bindParam(':phone_number', $phone_number);
              $stmt->bindParam(':subject', $subject);
              $stmt->bindParam(':message', $message);
              $stmt->bindParam(':user_ip', $user_ip);
              $stmt->bindParam(':timestamp', $timestamp);
              $stmt->execute();

              echo "Submitted successfully!";
          }
      }
  }
} catch (PDOException $e) {
  echo "Error: " . $e->getMessage();
}

$conn = null;
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Contact Us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  </head>
  <body>
    <div class="container" style="padding-top:100px;">
        <div class="row d-flex justify-content-center">
            <div class="col-md-6">
                <h4 class="mb-3 text-center">Contact Us<h4>
                <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post">
                  <div class="mb-3">
                    <label>Full Name</label>
                    <input type="text" class="form-control" name="full_name" placeholder="Enter Your Full Name" >
                  </div>
                  <div class="mb-3">
                    <label>Phone Number</label>
                    <input type="text" class="form-control" name="phone_number" maxlength="10" placeholder="1234567890" >
                  </div>
                  <div class="mb-3">
                    <label>Email</label>
                    <input type="email" class="form-control" name="email" placeholder="example@email.com" >
                  </div>
                  <div class="mb-3">
                    <label>Subject</label>
                    <input type="text" class="form-control" name="subject"  placeholder="Enter Subject" >
                  </div>
                  <div class="mb-3">
                    <label>Message</label>
                    <textarea  class="form-control" name="message" placeholder="Message" ></textarea>
                  </div>
                  <div class="mb-3">
                    <button type="submit" name="submit" class="btn btn-primary" style="float:right;">Submit</button>
                  </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
  </body>
</html>