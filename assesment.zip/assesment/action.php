<?php
$hostname = 'localhost';
$username = 'root';
$password= '';
$db_name = 'assesment';
$conn = mysqli_connect($hostname, $username, $password, $db_name);

if(isset($_POST['submit']))
{
    $full_name=$_POST['full_name'];
    $phone_number=$_POST['phone_number'];
    $email=$_POST['email'];
    $subject=$_POST['subject'];
    $message=$_POST['message'];
    $user_ip = $_SERVER['REMOTE_ADDR'];
    $timestamp=date('Y-m-d H:i:s');

    $sql="SELECT * FROM `contact_form` WHERE `phone_number`='$phone_number' OR `email`='$email'";
    $result=mysqli_query($conn,$sql);
    if(mysqli_num_rows($result) > 0)
    {
        header('location:contact-us.php?already_submitted');
    }
    else
    {
        $query="INSERT INTO `contact_form` (`full_name`,`phone_number`,`email`,`subject`,`message`,`user_ip`,`timestamp`) 
                VALUES ('$full_name','$phone_number','$email','$subject','$message','$user_ip','$timestamp')";
        if(mysqli_query($conn,$query))
        {
            header('location:contact-us.php?success');
        }
    }

}

?>